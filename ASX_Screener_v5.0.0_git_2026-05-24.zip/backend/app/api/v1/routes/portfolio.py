"""
ASX Screener — Portfolio Routes
=================================
All endpoints require authentication.

GET    /portfolio                          — list user's portfolios
POST   /portfolio                          — create portfolio
DELETE /portfolio/{id}                     — delete portfolio
GET    /portfolio/{id}/performance         — holdings + live P&L
GET    /portfolio/{id}/transactions        — full transaction history
POST   /portfolio/{id}/transactions        — add a transaction
DELETE /portfolio/{id}/transactions/{txn_id} — delete a transaction
POST   /portfolio/{id}/import/holdings     — CSV import (holdings format)
POST   /portfolio/{id}/import/transactions — CSV import (transactions format)
"""
import csv
import io
import logging
from collections import defaultdict
from datetime import date, timedelta

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.deps import get_current_user
from app.core.plans import get_limits
from app.db.session import get_db
from app.schemas.portfolio import (
    PortfolioCreate,
    PortfolioUpdate,
    PortfolioOut,
    PortfoliosResponse,
    TransactionAdd,
    TransactionOut,
    TransactionsResponse,
    HoldingRow,
    PortfolioPerformance,
    ImportResult,
)

log = logging.getLogger(__name__)
router = APIRouter()


# ── Helpers ───────────────────────────────────────────────────────────────────

async def _get_portfolio_or_404(portfolio_id: str, user_id: str, db: AsyncSession) -> dict:
    row = (await db.execute(
        text("SELECT id, name, description, is_smsf, created_at FROM users.portfolios WHERE id = :pid AND user_id = :uid"),
        {"pid": portfolio_id, "uid": user_id},
    )).mappings().fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Portfolio not found")
    return row


def _compute_holdings(txn_rows) -> dict[str, dict]:
    """
    Compute current holdings from transaction list.
    Returns {asx_code: {quantity, avg_cost, total_cost}}.
    Sells reduce quantity. avg_cost uses weighted average of buys only.
    """
    holdings: dict[str, dict] = {}
    for r in txn_rows:
        code  = r["asx_code"]
        ttype = r["transaction_type"]
        qty   = float(r["shares"])
        price = float(r["price_per_share"])
        brok  = float(r["brokerage"] or 0)

        if code not in holdings:
            holdings[code] = {"quantity": 0.0, "total_buy_cost": 0.0, "total_buy_qty": 0.0}

        h = holdings[code]
        if ttype in ("buy", "drp"):
            cost = qty * price + brok
            h["total_buy_cost"] += cost
            h["total_buy_qty"]  += qty
            h["quantity"]       += qty
        elif ttype == "sell":
            h["quantity"] -= qty

    # Remove fully sold positions, compute avg_cost
    result = {}
    for code, h in holdings.items():
        qty = round(h["quantity"], 4)
        if qty <= 0:
            continue
        avg = (h["total_buy_cost"] / h["total_buy_qty"]) if h["total_buy_qty"] > 0 else 0
        result[code] = {"quantity": qty, "avg_cost": avg, "cost_basis": qty * avg}
    return result


# ── List portfolios ───────────────────────────────────────────────────────────

@router.get("", response_model=PortfoliosResponse)
async def list_portfolios(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    rows = (await db.execute(
        text("SELECT id, name, description, is_smsf, created_at FROM users.portfolios WHERE user_id = :uid ORDER BY created_at ASC"),
        {"uid": current_user["id"]},
    )).mappings().all()
    return PortfoliosResponse(portfolios=[
        PortfolioOut(
            id=str(r["id"]),
            name=r["name"],
            description=r["description"],
            is_smsf=r["is_smsf"],
            created_at=r["created_at"].isoformat(),
        ) for r in rows
    ])


# ── Create portfolio ──────────────────────────────────────────────────────────

@router.post("", response_model=PortfolioOut, status_code=201)
async def create_portfolio(
    body: PortfolioCreate,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # Limit: free users max 3 portfolios
    count = (await db.execute(
        text("SELECT COUNT(*) FROM users.portfolios WHERE user_id = :uid"),
        {"uid": current_user["id"]},
    )).scalar()
    limit = get_limits(current_user.get("plan", "free"))["portfolios"]
    if (count or 0) >= limit:
        raise HTTPException(status_code=403, detail=f"Portfolio limit reached ({limit} for your plan)")

    row = (await db.execute(
        text("""
            INSERT INTO users.portfolios (user_id, name, description, is_smsf)
            VALUES (:uid, :name, :desc, :smsf)
            RETURNING id, name, description, is_smsf, created_at
        """),
        {"uid": current_user["id"], "name": body.name, "desc": body.description, "smsf": body.is_smsf},
    )).mappings().one()
    await db.commit()
    return PortfolioOut(
        id=str(row["id"]),
        name=row["name"],
        description=row["description"],
        is_smsf=row["is_smsf"],
        created_at=row["created_at"].isoformat(),
    )


# ── Rename / update portfolio ─────────────────────────────────────────────────

@router.patch("/{portfolio_id}", response_model=PortfolioOut)
async def update_portfolio(
    portfolio_id: str,
    body: PortfolioUpdate,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _get_portfolio_or_404(portfolio_id, current_user["id"], db)
    name = body.name.strip()
    if not name:
        raise HTTPException(status_code=422, detail="Portfolio name cannot be empty")
    params: dict = {"name": name, "desc": body.description, "pid": portfolio_id}
    smsf_clause = ""
    if body.is_smsf is not None:
        smsf_clause = ", is_smsf = :smsf"
        params["smsf"] = body.is_smsf
    row = (await db.execute(
        text(f"""
            UPDATE users.portfolios
            SET name = :name, description = :desc{smsf_clause}
            WHERE id = :pid
            RETURNING id, name, description, is_smsf, created_at
        """),
        params,
    )).mappings().one()
    await db.commit()
    return PortfolioOut(
        id=str(row["id"]),
        name=row["name"],
        description=row["description"],
        is_smsf=row["is_smsf"],
        created_at=row["created_at"].isoformat(),
    )


# ── Delete portfolio ──────────────────────────────────────────────────────────

@router.delete("/{portfolio_id}", status_code=204)
async def delete_portfolio(
    portfolio_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _get_portfolio_or_404(portfolio_id, current_user["id"], db)
    await db.execute(
        text("DELETE FROM users.portfolios WHERE id = :pid"),
        {"pid": portfolio_id},
    )
    await db.commit()


# ── Remove all transactions for a holding ────────────────────────────────────

@router.delete("/{portfolio_id}/holdings/{asx_code}", status_code=204)
async def remove_holding(
    portfolio_id: str,
    asx_code: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete every transaction for the given ASX code within this portfolio."""
    await _get_portfolio_or_404(portfolio_id, current_user["id"], db)
    await db.execute(
        text("DELETE FROM users.portfolio_transactions WHERE portfolio_id = :pid AND asx_code = :code"),
        {"pid": portfolio_id, "code": asx_code.upper()},
    )
    await db.commit()


# ── Performance (live P&L) ────────────────────────────────────────────────────

@router.get("/{portfolio_id}/performance", response_model=PortfolioPerformance)
async def get_performance(
    portfolio_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    p = await _get_portfolio_or_404(portfolio_id, current_user["id"], db)

    # Fetch all transactions ordered oldest → newest for correct avg cost
    txn_rows = (await db.execute(
        text("""
            SELECT asx_code, transaction_type, shares, price_per_share, brokerage
            FROM users.portfolio_transactions
            WHERE portfolio_id = :pid
            ORDER BY transaction_date ASC, id ASC
        """),
        {"pid": portfolio_id},
    )).mappings().all()

    holdings = _compute_holdings(txn_rows)

    if not holdings:
        return PortfolioPerformance(
            portfolio_id=portfolio_id,
            portfolio_name=p["name"],
            total_cost=0, total_value=None, total_gain_loss=None,
            total_gain_loss_pct=None, total_change_1d=None, total_change_1d_pct=None,
            annual_income=None, portfolio_yield=None,
            holdings=[],
        )

    # Enrich with live data from screener.universe
    codes = list(holdings.keys())
    # Use individual placeholders — asyncpg doesn't coerce Python lists in text() queries
    placeholders = ', '.join(f':c{i}' for i in range(len(codes)))
    code_params  = {f'c{i}': code for i, code in enumerate(codes)}
    universe_rows = (await db.execute(
        text(f"""
            SELECT asx_code, company_name, sector, price, dps_ttm, dividend_yield, franking_pct
            FROM screener.universe
            WHERE asx_code IN ({placeholders})
        """),
        code_params,
    )).mappings().all()
    live = {r["asx_code"]: r for r in universe_rows}

    # Fetch previous trading day's close for daily change calculation
    prev_rows = (await db.execute(
        text(f"""
            SELECT DISTINCT ON (asx_code) asx_code, close AS prev_close
            FROM market.daily_prices
            WHERE asx_code IN ({placeholders})
              AND time::date < CURRENT_DATE
            ORDER BY asx_code, time DESC
        """),
        code_params,
    )).mappings().all()
    prev_prices = {r["asx_code"]: float(r["prev_close"]) for r in prev_rows if r["prev_close"] is not None}

    rows: list[HoldingRow] = []
    total_cost = total_value = total_income = total_change_1d = 0.0

    for code, h in sorted(holdings.items()):
        qty        = h["quantity"]
        avg_cost   = h["avg_cost"]
        cost_basis = h["cost_basis"]
        total_cost += cost_basis

        u = live.get(code)
        cur_price   = float(u["price"])          if u and u["price"]         is not None else None
        cur_value   = qty * cur_price             if cur_price is not None    else None
        gain_loss   = (cur_value - cost_basis)    if cur_value is not None    else None
        gain_pct    = (gain_loss / cost_basis * 100) if (gain_loss is not None and cost_basis > 0) else None
        dps         = float(u["dps_ttm"])         if u and u["dps_ttm"]       is not None else None
        ann_income  = qty * dps                   if dps is not None          else None
        d_yield     = float(u["dividend_yield"])  if u and u["dividend_yield"] is not None else None
        franking    = float(u["franking_pct"])    if u and u["franking_pct"]  is not None else None

        prev_close  = prev_prices.get(code)
        chg_1d      = ((cur_price - prev_close) * qty) if (cur_price and prev_close) else None

        if cur_value is not None:
            total_value = (total_value or 0) + cur_value
        if ann_income is not None:
            total_income = (total_income or 0) + ann_income
        if chg_1d is not None:
            total_change_1d = (total_change_1d or 0) + chg_1d

        rows.append(HoldingRow(
            asx_code=code,
            company_name=u["company_name"] if u else None,
            sector=u["sector"] if u else None,
            quantity=qty,
            avg_cost=avg_cost,
            cost_basis=cost_basis,
            current_price=cur_price,
            current_value=cur_value,
            gain_loss=gain_loss,
            gain_loss_pct=gain_pct,
            dividend_yield=d_yield,
            annual_income=ann_income,
            franking_pct=franking,
        ))

    total_gl      = (total_value - total_cost)    if total_value is not None  else None
    total_gl_pct  = (total_gl / total_cost * 100) if (total_gl is not None and total_cost > 0) else None
    port_yield    = (total_income / total_value * 100) if (total_income and total_value) else None

    # Daily change: use prev total value as denominator so the % is correct
    _chg          = total_change_1d if total_change_1d else None
    _prev_total   = ((total_value or 0) - (total_change_1d or 0)) if total_value else None
    _chg_pct      = (_chg / _prev_total * 100) if (_chg and _prev_total and _prev_total > 0) else None

    return PortfolioPerformance(
        portfolio_id=portfolio_id,
        portfolio_name=p["name"],
        total_cost=total_cost,
        total_value=total_value,
        total_gain_loss=total_gl,
        total_gain_loss_pct=total_gl_pct,
        total_change_1d=_chg,
        total_change_1d_pct=_chg_pct,
        annual_income=total_income if total_income else None,
        portfolio_yield=port_yield,
        holdings=rows,
    )


# ── Transaction list ──────────────────────────────────────────────────────────

@router.get("/{portfolio_id}/transactions", response_model=TransactionsResponse)
async def list_transactions(
    portfolio_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _get_portfolio_or_404(portfolio_id, current_user["id"], db)
    rows = (await db.execute(
        text("""
            SELECT id, asx_code, transaction_type, transaction_date,
                   shares, price_per_share, brokerage, total_cost, notes
            FROM users.portfolio_transactions
            WHERE portfolio_id = :pid
            ORDER BY transaction_date DESC, id DESC
        """),
        {"pid": portfolio_id},
    )).mappings().all()
    return TransactionsResponse(transactions=[
        TransactionOut(
            id=r["id"],
            asx_code=r["asx_code"],
            transaction_type=r["transaction_type"],
            transaction_date=str(r["transaction_date"]),
            shares=float(r["shares"]),
            price_per_share=float(r["price_per_share"]),
            brokerage=float(r["brokerage"] or 0),
            total_cost=float(r["total_cost"]) if r["total_cost"] is not None else None,
            notes=r["notes"],
        ) for r in rows
    ])


# ── Add transaction ───────────────────────────────────────────────────────────

@router.post("/{portfolio_id}/transactions", response_model=TransactionOut, status_code=201)
async def add_transaction(
    portfolio_id: str,
    body: TransactionAdd,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _get_portfolio_or_404(portfolio_id, current_user["id"], db)
    total = body.shares * body.price_per_share + body.brokerage
    row = (await db.execute(
        text("""
            INSERT INTO users.portfolio_transactions
                (portfolio_id, asx_code, transaction_type, transaction_date,
                 shares, price_per_share, brokerage, total_cost, notes)
            VALUES (:pid, :code, :ttype, :tdate, :shares, :price, :brok, :total, :notes)
            RETURNING id, asx_code, transaction_type, transaction_date,
                      shares, price_per_share, brokerage, total_cost, notes
        """),
        {
            "pid": portfolio_id, "code": body.asx_code, "ttype": body.transaction_type,
            "tdate": body.transaction_date, "shares": body.shares,
            "price": body.price_per_share, "brok": body.brokerage,
            "total": total, "notes": body.notes,
        },
    )).mappings().one()
    await db.commit()
    return TransactionOut(
        id=row["id"],
        asx_code=row["asx_code"],
        transaction_type=row["transaction_type"],
        transaction_date=str(row["transaction_date"]),
        shares=float(row["shares"]),
        price_per_share=float(row["price_per_share"]),
        brokerage=float(row["brokerage"] or 0),
        total_cost=float(row["total_cost"]) if row["total_cost"] is not None else None,
        notes=row["notes"],
    )


# ── Delete transaction ────────────────────────────────────────────────────────

@router.delete("/{portfolio_id}/transactions/{txn_id}", status_code=204)
async def delete_transaction(
    portfolio_id: str,
    txn_id: int,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    await _get_portfolio_or_404(portfolio_id, current_user["id"], db)
    result = await db.execute(
        text("DELETE FROM users.portfolio_transactions WHERE id = :tid AND portfolio_id = :pid"),
        {"tid": txn_id, "pid": portfolio_id},
    )
    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="Transaction not found")
    await db.commit()


# ── CSV Import — holdings format ──────────────────────────────────────────────

@router.post("/{portfolio_id}/import/holdings", response_model=ImportResult)
async def import_holdings_csv(
    portfolio_id: str,
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Expected CSV columns: asx_code, quantity, avg_cost, purchase_date (optional)
    Creates one BUY transaction per row using avg_cost as the price.
    """
    await _get_portfolio_or_404(portfolio_id, current_user["id"], db)

    content = (await file.read()).decode("utf-8-sig")
    reader  = csv.DictReader(io.StringIO(content))

    imported = skipped = 0
    errors: list[str] = []

    for i, row in enumerate(reader, start=2):
        try:
            code  = row.get("asx_code", "").strip().upper()
            qty   = float(row.get("quantity", "").strip())
            cost  = float(row.get("avg_cost", "").strip())
            raw_date = row.get("purchase_date", "").strip() or "2000-01-01"
            txn_date = date.fromisoformat(raw_date)

            if not code or qty <= 0 or cost <= 0:
                raise ValueError("asx_code, quantity, and avg_cost are required and must be positive")

            await db.execute(
                text("""
                    INSERT INTO users.portfolio_transactions
                        (portfolio_id, asx_code, transaction_type, transaction_date,
                         shares, price_per_share, brokerage, total_cost)
                    VALUES (:pid, :code, 'buy', :tdate, :qty, :price, 0, :total)
                """),
                {"pid": portfolio_id, "code": code, "tdate": txn_date,
                 "qty": qty, "price": cost, "total": qty * cost},
            )
            imported += 1
        except Exception as e:
            errors.append(f"Row {i}: {e}")
            skipped += 1

    await db.commit()
    return ImportResult(imported=imported, skipped=skipped, errors=errors[:20])

# ── CSV Import — transactions format ─────────────────────────────────────────

@router.post("/{portfolio_id}/import/transactions", response_model=ImportResult)
async def import_transactions_csv(
    portfolio_id: str,
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Expected CSV columns: date, asx_code, type, quantity, price, brokerage (optional)
    Supports Sharesight-style exports.
    """
    await _get_portfolio_or_404(portfolio_id, current_user["id"], db)

    content = (await file.read()).decode("utf-8-sig")
    reader  = csv.DictReader(io.StringIO(content))

    imported = skipped = 0
    errors: list[str] = []

    for i, row in enumerate(reader, start=2):
        try:
            # Flexible column name matching
            code  = (row.get("asx_code") or row.get("code") or row.get("symbol") or "").strip().upper()
            ttype = (row.get("type") or row.get("transaction_type") or "buy").strip().lower()
            qty   = float((row.get("quantity") or row.get("shares") or "0").strip())
            price = float((row.get("price") or row.get("price_per_share") or "0").strip())
            brok  = float((row.get("brokerage") or row.get("commission") or "0").strip())
            raw_date = (row.get("date") or row.get("transaction_date") or "").strip()
            txn_date = date.fromisoformat(raw_date)

            if ttype not in ("buy", "sell", "drp"):
                ttype = "buy"
            if not code or qty <= 0 or price <= 0:
                raise ValueError("asx_code, quantity, and price are required and must be positive")

            total = qty * price + (brok if ttype == "buy" else -brok)
            await db.execute(
                text("""
                    INSERT INTO users.portfolio_transactions
                        (portfolio_id, asx_code, transaction_type, transaction_date,
                         shares, price_per_share, brokerage, total_cost)
                    VALUES (:pid, :code, :ttype, :tdate, :qty, :price, :brok, :total)
                """),
                {"pid": portfolio_id, "code": code, "ttype": ttype, "tdate": txn_date,
                 "qty": qty, "price": price, "brok": brok, "total": total},
            )
            imported += 1
        except Exception as e:
            errors.append(f"Row {i}: {e}")
            skipped += 1

    await db.commit()
    return ImportResult(imported=imported, skipped=skipped, errors=errors[:20])


# ── Portfolio value history ───────────────────────────────────────────────────

@router.get("/{portfolio_id}/history")
async def get_portfolio_history(
    portfolio_id: str,
    period: str = "1y",
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Daily portfolio value history — replays transactions against price history.
    period: 1m | 3m | 6m | 1y | 2y | all
    """
    await _get_portfolio_or_404(portfolio_id, current_user["id"], db)

    period_days = {"1m": 30, "3m": 90, "6m": 180, "1y": 365, "2y": 730, "all": 3650}
    days = period_days.get(period, 365)

    txn_rows = (await db.execute(text("""
        SELECT asx_code, transaction_type, transaction_date,
               shares, price_per_share, brokerage
        FROM users.portfolio_transactions
        WHERE portfolio_id = :pid
        ORDER BY transaction_date ASC, created_at ASC
    """), {"pid": portfolio_id})).mappings().all()

    if not txn_rows:
        return {"portfolio_id": portfolio_id, "period": period, "history": []}

    from datetime import timedelta, date as date_type
    end_date   = date_type.today()
    start_date = end_date - timedelta(days=days)
    first_txn_date = txn_rows[0]["transaction_date"]
    if hasattr(first_txn_date, 'date'):
        first_txn_date = first_txn_date.date()
    start_date = max(start_date, first_txn_date)

    codes = list({r["asx_code"] for r in txn_rows})
    placeholders = ", ".join(f":c{i}" for i in range(len(codes)))
    code_params  = {f"c{i}": code for i, code in enumerate(codes)}

    price_start = min(start_date, first_txn_date) - timedelta(days=5)
    price_rows = (await db.execute(text(f"""
        SELECT asx_code, time::date AS price_date, close
        FROM market.daily_prices
        WHERE asx_code IN ({placeholders})
          AND time::date BETWEEN :start AND :end
        ORDER BY time ASC
    """), {**code_params, "start": price_start, "end": end_date})).mappings().all()

    prices: dict[str, dict] = {}
    for r in price_rows:
        prices.setdefault(r["asx_code"], {})[r["price_date"]] = float(r["close"])

    all_dates = sorted({r["price_date"] for r in price_rows if r["price_date"] >= start_date})

    holdings_state: dict[str, dict] = {}
    txn_idx = 0
    txns_list = list(txn_rows)
    history = []

    for d in all_dates:
        while txn_idx < len(txns_list):
            t = txns_list[txn_idx]
            txn_date = t["transaction_date"]
            if hasattr(txn_date, 'date'):
                txn_date = txn_date.date()
            if txn_date > d:
                break
            code  = t["asx_code"]
            qty   = float(t["shares"])
            price = float(t["price_per_share"])
            brok  = float(t["brokerage"] or 0)
            ttype = t["transaction_type"]
            if code not in holdings_state:
                holdings_state[code] = {"quantity": 0.0, "cost": 0.0}
            h = holdings_state[code]
            if ttype in ("buy", "drp"):
                h["cost"]     += qty * price + brok
                h["quantity"] += qty
            elif ttype == "sell":
                if h["quantity"] > 0:
                    ratio = qty / h["quantity"]
                    h["cost"] -= h["cost"] * ratio
                h["quantity"] -= qty
                if h["quantity"] < 0.0001:
                    h["quantity"] = 0.0
                    h["cost"]     = 0.0
            txn_idx += 1

        total_value = total_cost = 0.0
        for code, h in holdings_state.items():
            if h["quantity"] <= 0:
                continue
            day_price = None
            for offset in range(5):
                day_price = prices.get(code, {}).get(d - timedelta(days=offset))
                if day_price is not None:
                    break
            if day_price is None:
                continue
            total_value += h["quantity"] * day_price
            total_cost  += h["cost"]

        if total_value > 0:
            history.append({
                "date":      d.isoformat(),
                "value":     round(total_value, 2),
                "cost":      round(total_cost, 2),
                "gain_loss": round(total_value - total_cost, 2),
            })

    return {"portfolio_id": portfolio_id, "period": period, "history": history}


# ── Dividend calendar for holdings ────────────────────────────────────────────

@router.get("/{portfolio_id}/dividends")
async def get_portfolio_dividends(
    portfolio_id: str,
    months_ahead: int = 6,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Upcoming ex-dividend events for current portfolio holdings +
    last 12 months of received dividends.
    """
    await _get_portfolio_or_404(portfolio_id, current_user["id"], db)

    txn_rows = (await db.execute(text("""
        SELECT asx_code, transaction_type, shares, price_per_share, brokerage
        FROM users.portfolio_transactions
        WHERE portfolio_id = :pid
        ORDER BY transaction_date ASC
    """), {"pid": portfolio_id})).mappings().all()

    holdings = _compute_holdings(txn_rows)
    if not holdings:
        return {"portfolio_id": portfolio_id, "upcoming": [], "received": []}

    codes = list(holdings.keys())
    placeholders = ", ".join(f":c{i}" for i in range(len(codes)))
    code_params  = {f"c{i}": code for i, code in enumerate(codes)}

    from datetime import timedelta, date as date_type
    today      = date_type.today()
    future_end = today + timedelta(days=months_ahead * 30)
    past_start = today - timedelta(days=365)

    upcoming_rows = (await db.execute(text(f"""
        SELECT d.asx_code, d.ex_date, d.pay_date AS payment_date,
               d.amount_per_share AS amount,
               d.franking_pct, d.dividend_type AS div_type, u.company_name
        FROM market.dividends d
        LEFT JOIN screener.universe u ON u.asx_code = d.asx_code
        WHERE d.asx_code IN ({placeholders})
          AND d.ex_date >= :today AND d.ex_date <= :future_end
          AND d.amount_per_share > 0
        ORDER BY d.ex_date ASC
    """), {**code_params, "today": today, "future_end": future_end})).mappings().all()

    received_rows = (await db.execute(text(f"""
        SELECT d.asx_code, d.ex_date, d.pay_date AS payment_date,
               d.amount_per_share AS amount,
               d.franking_pct, d.dividend_type AS div_type, u.company_name
        FROM market.dividends d
        LEFT JOIN screener.universe u ON u.asx_code = d.asx_code
        WHERE d.asx_code IN ({placeholders})
          AND d.ex_date >= :past_start AND d.ex_date < :today
          AND d.amount_per_share > 0
        ORDER BY d.ex_date DESC LIMIT 50
    """), {**code_params, "past_start": past_start, "today": today})).mappings().all()

    def _f(v): return float(v) if v is not None else None

    def enrich(rows):
        result = []
        for r in rows:
            code     = r["asx_code"]
            qty      = holdings.get(code, {}).get("quantity", 0)
            amount   = _f(r["amount"]) or 0
            franking = _f(r["franking_pct"]) or 0
            est      = round(qty * amount, 2) if qty > 0 else None
            gross    = round(est / (1 - 0.30 * (franking / 100)), 2) if est and franking > 0 else est
            result.append({
                "asx_code":     code,
                "company_name": r["company_name"],
                "ex_date":      r["ex_date"].isoformat() if r["ex_date"] else None,
                "payment_date": r["payment_date"].isoformat() if r["payment_date"] else None,
                "amount":       amount,
                "franking_pct": franking,
                "div_type":     r["div_type"],
                "quantity":     qty,
                "est_income":   est,
                "gross_income": gross,
            })
        return result

    return {
        "portfolio_id": portfolio_id,
        "upcoming": enrich(upcoming_rows),
        "received": enrich(received_rows),
    }


# ── CGT Tax Report ────────────────────────────────────────────────────────────

@router.get("/{portfolio_id}/tax-report")
async def get_tax_report(
    portfolio_id: str,
    tax_year: int = None,   # e.g. 2025 means FY2024-25 (Jul 2024 – Jun 2025)
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Capital Gains Tax report for an Australian financial year (Jul–Jun).
    Uses FIFO cost-base matching. Applies 50% CGT discount for parcels held > 12 months.
    tax_year=2025 → FY2024-25 (1 Jul 2024 – 30 Jun 2025)
    """
    await _get_portfolio_or_404(portfolio_id, current_user["id"], db)

    # Default to current Australian financial year
    today = date.today()
    if tax_year is None:
        tax_year = today.year if today.month >= 7 else today.year - 1
        tax_year += 1  # FY ending year

    fy_start = date(tax_year - 1, 7, 1)
    fy_end   = date(tax_year, 6, 30)

    # Fetch all transactions up to end of this FY, ordered by date
    rows = (await db.execute(text("""
        SELECT asx_code, transaction_type, transaction_date, shares, price_per_share, brokerage
        FROM users.portfolio_transactions
        WHERE portfolio_id = :pid
          AND transaction_date <= :fy_end
          AND transaction_type IN ('buy', 'sell', 'drp')
        ORDER BY transaction_date ASC, id ASC
    """), {"pid": portfolio_id, "fy_end": fy_end})).mappings().all()

    # FIFO lot tracking: {asx_code: [(buy_date, qty, unit_cost)]}
    lots: dict[str, list] = defaultdict(list)
    disposals = []

    for r in rows:
        code  = r["asx_code"]
        ttype = r["transaction_type"]
        qty   = float(r["shares"])
        price = float(r["price_per_share"])
        brok  = float(r["brokerage"] or 0)
        txn_date = r["transaction_date"]

        if ttype in ("buy", "drp"):
            unit_cost = (qty * price + brok) / qty
            lots[code].append({"date": txn_date, "qty": qty, "unit_cost": unit_cost})

        elif ttype == "sell":
            proceeds = qty * price - brok
            remaining_sell = qty
            cost_base = 0.0
            matched_lots = []

            while remaining_sell > 0 and lots[code]:
                lot = lots[code][0]
                take = min(remaining_sell, lot["qty"])
                cost_base       += take * lot["unit_cost"]
                matched_lots.append({"buy_date": lot["date"], "qty": take, "unit_cost": lot["unit_cost"]})
                lot["qty"]      -= take
                remaining_sell  -= take
                if lot["qty"] < 0.0001:
                    lots[code].pop(0)

            capital_gain = proceeds - cost_base
            # Oldest lot date for discount eligibility (conservative: use first matched lot)
            oldest_buy = matched_lots[0]["buy_date"] if matched_lots else txn_date
            held_days  = (txn_date - oldest_buy).days
            discount_eligible = held_days >= 365 and capital_gain > 0
            discounted_gain   = capital_gain * 0.5 if discount_eligible else capital_gain

            disposals.append({
                "asx_code":          code,
                "sell_date":         txn_date.isoformat(),
                "buy_date":          oldest_buy.isoformat(),
                "quantity":          round(qty, 4),
                "proceeds":          round(proceeds, 2),
                "cost_base":         round(cost_base, 2),
                "capital_gain":      round(capital_gain, 2),
                "held_days":         held_days,
                "discount_eligible": discount_eligible,
                "discounted_gain":   round(discounted_gain, 2),
                "in_fy":             fy_start <= txn_date <= fy_end,
            })

    # Filter to this FY only for summary
    fy_disposals = [d for d in disposals if d["in_fy"]]

    total_proceeds    = sum(d["proceeds"]       for d in fy_disposals)
    total_cost_base   = sum(d["cost_base"]      for d in fy_disposals)
    gross_gain        = sum(d["capital_gain"]   for d in fy_disposals)
    discount_amount   = sum(
        d["capital_gain"] * 0.5
        for d in fy_disposals
        if d["discount_eligible"]
    )
    net_gain          = sum(d["discounted_gain"] for d in fy_disposals)
    losses            = sum(d["capital_gain"]    for d in fy_disposals if d["capital_gain"] < 0)
    gains             = sum(d["capital_gain"]    for d in fy_disposals if d["capital_gain"] > 0)

    return {
        "portfolio_id":   portfolio_id,
        "tax_year":       tax_year,
        "fy_label":       f"FY{tax_year - 1}–{str(tax_year)[2:]}",
        "fy_start":       fy_start.isoformat(),
        "fy_end":         fy_end.isoformat(),
        "summary": {
            "total_proceeds":  round(total_proceeds, 2),
            "total_cost_base": round(total_cost_base, 2),
            "gross_gain":      round(gross_gain, 2),
            "discount_amount": round(discount_amount, 2),
            "net_gain":        round(net_gain, 2),
            "total_gains":     round(gains, 2),
            "total_losses":    round(losses, 2),
            "disposal_count":  len(fy_disposals),
        },
        "disposals": fy_disposals,
    }
